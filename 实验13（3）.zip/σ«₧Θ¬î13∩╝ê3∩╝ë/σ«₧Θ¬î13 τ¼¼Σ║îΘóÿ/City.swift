//
//  City.swift
//  实验13 第二题
//
//  Created by apple on 2018/12/03.
//  Copyright © 2018年 apple. All rights reserved.
//

import Foundation
class City{
    var id:String?
    var name:String?
    init(id:String, name:String){
        self.id = id
        self.name = name
    }
}
